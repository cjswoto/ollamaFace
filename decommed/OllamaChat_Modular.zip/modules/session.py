import os
import json
import datetime

class SessionManager:
    def __init__(self, directory="sessions"):
        self.directory = directory
        os.makedirs(self.directory, exist_ok=True)
        self.current_session = None

    def create_new_session(self):
        timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        self.current_session = {
            "id": f"session_{timestamp}",
            "messages": [],
            "created_at": timestamp,
            "updated_at": timestamp
        }

    def save_session(self):
        if not self.current_session:
            return
        filepath = os.path.join(self.directory, f"{self.current_session['id']}.json")
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.current_session, f, indent=2)

    def load_sessions(self):
        sessions = []
        for file in os.listdir(self.directory):
            if file.endswith(".json"):
                with open(os.path.join(self.directory, file), "r", encoding="utf-8") as f:
                    sessions.append(json.load(f))
        return sessions
