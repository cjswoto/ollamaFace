import tkinter as tk
from tkinter import filedialog, ttk, scrolledtext, messagebox
import ttkbootstrap as tb
from ttkbootstrap.constants import *
from PIL import Image, ImageTk
import json
import os
import datetime
import threading
from modules.search import perform_web_search
from modules.session import SessionManager

class OllamaGUI:
    def __init__(self, parent):
        if hasattr(parent, "title"):
            parent.title("OllamaChat - Local LLM Interface")
            self.root = parent
        else:
            self.root = tk.Frame(parent)
            self.root.pack(fill=tk.BOTH, expand=True)

        self.style = tb.Style(theme="darkly")
        self.current_model = tk.StringVar()
        self.web_search_enabled = tk.BooleanVar(value=True)
        self.message_history = []
        self.session_manager = SessionManager()
        self.setup_ui()
        self.new_session()

    def setup_ui(self):
        self.paned = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        self.paned.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.chat_frame = ttk.Frame(self.paned)
        self.paned.add(self.chat_frame, weight=3)

        self.settings_frame = ttk.Frame(self.paned)
        self.paned.add(self.settings_frame, weight=1)

        self.setup_chat_interface()

    def setup_chat_interface(self):
        self.chat_display = scrolledtext.ScrolledText(self.chat_frame, wrap=tk.WORD, height=20)
        self.chat_display.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        self.chat_display.config(state=tk.DISABLED)

        self.message_input = scrolledtext.ScrolledText(self.chat_frame, height=4, wrap=tk.WORD)
        self.message_input.pack(fill=tk.X, pady=(0, 5))
        self.message_input.bind("<Return>", self.send_message)

        button_frame = ttk.Frame(self.chat_frame)
        button_frame.pack(fill=tk.X)

        self.web_search_checkbox = ttk.Checkbutton(button_frame, text="Enable Web Search", variable=self.web_search_enabled)
        self.web_search_checkbox.pack(side=tk.LEFT)

        self.send_button = ttk.Button(button_frame, text="Send", command=self.send_message)
        self.send_button.pack(side=tk.RIGHT)

    def send_message(self, event=None):
        message = self.message_input.get("1.0", tk.END).strip()
        if not message:
            return

        if self.web_search_enabled.get():
            search_results = perform_web_search(message)
            self.display_message("Search Results", search_results)

        self.display_message("You", message)
        self.message_input.delete("1.0", tk.END)

    def display_message(self, sender, message):
        self.chat_display.config(state=tk.NORMAL)
        self.chat_display.insert(tk.END, f"{sender}: {message}\n\n")
        self.chat_display.see(tk.END)
        self.chat_display.config(state=tk.DISABLED)

    def new_session(self):
        self.session_manager.create_new_session()
        self.chat_display.config(state=tk.NORMAL)
        self.chat_display.delete("1.0", tk.END)
        self.chat_display.config(state=tk.DISABLED)
